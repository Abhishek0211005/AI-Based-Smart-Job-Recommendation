# NexusJobs AI — Smart Job Recommendation System

A full-stack AI-based Job Recommendation System that uses heuristic search algorithms
(A*, Hill Climbing, Best-First Search, DFS) to match jobs to user skills.

---

## Project Structure

```
nexusjobs/
├── backend/
│   ├── algorithms/
│   │   └── jobAI.js          ← All AI algorithms (A*, Hill, BFS, DFS)
│   ├── data/
│   │   └── jobs.json         ← Job database (15 jobs)
│   ├── uploads/              ← Resume uploads (auto-created)
│   ├── server.js             ← Express REST API
│   └── package.json
│
├── frontend/
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── components/
│   │   │   ├── Sidebar.jsx   ← User input panel
│   │   │   ├── JobCard.jsx   ← Job result card
│   │   │   ├── GapAnalysis.jsx ← Skill gap view
│   │   │   └── Analytics.jsx ← Charts
│   │   ├── pages/
│   │   │   └── AlgoLab.jsx   ← Algorithm comparison
│   │   ├── utils/
│   │   │   ├── api.js        ← Axios API calls
│   │   │   └── localFallback.js ← Works without backend
│   │   ├── App.jsx           ← Main app
│   │   ├── App.css           ← All styles
│   │   └── index.js
│   └── package.json
│
└── README.md
```

---

## Setup & Run

### Step 1 — Install Backend

```bash
cd nexusjobs/backend
npm install
```

### Step 2 — Start Backend

```bash
npm run dev
# Runs on http://localhost:5000
```

### Step 3 — Install Frontend (new terminal)

```bash
cd nexusjobs/frontend
npm install
```

### Step 4 — Start Frontend

```bash
npm start
# Opens http://localhost:3000
```

> **Note:** The frontend works even without the backend (using local fallback).
> For full features (resume parsing, live algo comparison), run both.

---

## AI Algorithms Implemented

### 1. A* Search (`/algorithms/jobAI.js`)
- **f(n) = g(n) + h(n)**
- g(n) = actual cost (experience mismatch penalty)
- h(n) = heuristic (weighted skill match %)
- **Optimal and complete** — best results

### 2. Hill Climbing
- Greedy local search
- Always moves to best neighbor
- Fast but can miss global optimum

### 3. Best-First Search
- Expands node with best heuristic value
- Priority queue approach
- Ignores path cost

### 4. DFS with Heuristic Pruning
- Depth-first traversal
- Prunes jobs below score threshold
- Thorough but slower

### Heuristic Scoring Formula
```
score = (requiredMatch/totalRequired) × 60
      + (optionalMatch/totalOptional) × 25
      + bonusSkillMatches × 3 (max 10)
      + experienceLevelBonus (5)
      + domainPreferenceBonus (5)
      = max 100%
```

---

## API Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/jobs` | All jobs |
| GET | `/api/skills` | All unique skills |
| POST | `/api/recommend` | AI recommendations |
| POST | `/api/gap-analysis` | Skill gap for a job |
| POST | `/api/compare-algorithms` | Run all 4 algorithms |
| POST | `/api/upload-resume` | Parse resume for skills |

### Example: POST /api/recommend
```json
{
  "skills": ["Python", "React", "SQL"],
  "expLevel": "intermediate",
  "domain": "data",
  "location": "remote",
  "algorithm": "astar"
}
```

---

## Features

- Select from 30+ skills or add custom ones
- Upload resume (PDF/TXT) for auto skill extraction
- Experience level: Fresher / Mid-Level / Senior
- Domain filter: Web, Data, Mobile, DevOps, Backend, Security
- Location filter: Remote / Hybrid / Onsite
- 4 algorithm options with real-time switching
- Match % with color-coded progress bars
- Skill pills showing matched (blue), missing (red), optional (amber)
- Skill Gap Analysis with AI improvement suggestions
- Visual Analytics: bar charts, donut charts, salary comparison
- Algorithm Lab: radar chart, time/nodes comparison
- Save favorite jobs
- Sort by match %, salary, or alphabetically
- Responsive design

---

## Tech Stack

- **Frontend:** React.js, Chart.js, react-chartjs-2, Axios
- **Backend:** Node.js, Express.js, Multer, pdf-parse
- **Database:** JSON flat-file (jobs.json)
- **Algorithms:** A*, Hill Climbing, BFS, DFS (pure JavaScript)
