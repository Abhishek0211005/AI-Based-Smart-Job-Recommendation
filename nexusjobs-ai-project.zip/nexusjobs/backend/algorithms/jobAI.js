/**
 * AI Job Recommendation Algorithms
 * Implements: A*, Hill Climbing, Best-First Search, DFS Heuristic
 */

/**
 * HEURISTIC FUNCTION
 * Calculates match score between user profile and a job
 * Score breakdown:
 *   - Required skills match: 60 points max
 *   - Optional skills match: 25 points max
 *   - Bonus skills (extra matches): 10 points max
 *   - Experience level match: 5 points
 */
function heuristic(job, userSkills, expLevel, domain) {
  const userSet = new Set(userSkills.map((s) => s.toLowerCase()));
  const jobRequired = job.required.map((s) => s.toLowerCase());
  const jobOptional = job.optional.map((s) => s.toLowerCase());
  const allJobSkills = job.skills.map((s) => s.toLowerCase());

  let score = 0;
  let reqMatch = 0;
  let optMatch = 0;

  // Required skill match (weight: 60)
  jobRequired.forEach((s) => {
    if (userSet.has(s)) reqMatch++;
  });
  const reqRatio = jobRequired.length > 0 ? reqMatch / jobRequired.length : 0;

  // Optional skill match (weight: 25)
  jobOptional.forEach((s) => {
    if (userSet.has(s)) optMatch++;
  });
  const optRatio = jobOptional.length > 0 ? optMatch / jobOptional.length : 0;

  score = reqRatio * 60 + optRatio * 25;

  // Bonus: extra skills beyond required and optional (weight: 10 max)
  let bonusSkills = 0;
  userSet.forEach((s) => {
    if (
      allJobSkills.includes(s) &&
      !jobRequired.includes(s) &&
      !jobOptional.includes(s)
    ) {
      bonusSkills++;
    }
  });
  score += Math.min(bonusSkills * 3, 10);

  // Experience level bonus (weight: 5)
  if (job.experience.includes(expLevel)) score += 5;

  // Domain preference bonus (weight: 5)
  if (domain && domain !== "all" && job.domain === domain) score += 5;

  return Math.min(Math.round(score), 100);
}

/**
 * A* SEARCH ALGORITHM
 * f(n) = g(n) + h(n)
 * g(n) = actual cost (experience mismatch penalty)
 * h(n) = heuristic score (skill match percentage)
 * Best overall: optimal and complete
 */
function aStarSearch(jobs, userSkills, expLevel, domain) {
  const startTime = Date.now();
  let nodesExplored = 0;

  // Open list: all jobs to evaluate
  const openList = jobs.map((job) => {
    nodesExplored++;
    const h = heuristic(job, userSkills, expLevel, domain);
    const g = job.experience.includes(expLevel) ? 0 : 5; // cost: experience mismatch
    return {
      ...job,
      score: h,
      g: g,
      h: h,
      f: h - g, // A*: maximize f (higher is better)
      algorithm: "astar",
      nodesExplored,
    };
  });

  // Sort by f value descending (best match first)
  const sorted = openList.sort((a, b) => b.f - a.f);

  return {
    results: sorted,
    nodesExplored,
    timeMs: Date.now() - startTime,
    algorithm: "A* Search",
  };
}

/**
 * HILL CLIMBING ALGORITHM
 * Greedy local search — always moves to best neighbor
 * Fast but may get stuck in local optima
 */
function hillClimbing(jobs, userSkills, expLevel, domain) {
  const startTime = Date.now();
  let nodesExplored = 0;

  // Score all jobs
  let current = jobs.map((job) => {
    nodesExplored++;
    return {
      ...job,
      score: heuristic(job, userSkills, expLevel, domain),
      algorithm: "hill",
    };
  });

  // Simulate hill climbing: iterative improvement passes
  let improved = true;
  let passes = 0;
  while (improved && passes < 3) {
    improved = false;
    passes++;
    for (let i = 0; i < current.length - 1; i++) {
      nodesExplored++;
      // Swap if neighbor has better score (bubble up)
      if (current[i].score < current[i + 1].score) {
        [current[i], current[i + 1]] = [current[i + 1], current[i]];
        improved = true;
      }
    }
  }

  return {
    results: current,
    nodesExplored,
    timeMs: Date.now() - startTime,
    algorithm: "Hill Climbing",
  };
}

/**
 * BEST-FIRST SEARCH (Greedy)
 * Expands node with best heuristic value from frontier
 * Uses a priority queue approach
 */
function bestFirstSearch(jobs, userSkills, expLevel, domain) {
  const startTime = Date.now();
  let nodesExplored = 0;
  const visited = [];

  // Build frontier (priority queue simulation)
  let frontier = jobs.map((job) => ({
    ...job,
    score: heuristic(job, userSkills, expLevel, domain),
    algorithm: "bfs",
  }));

  // Extract best node repeatedly (greedy)
  while (frontier.length > 0) {
    nodesExplored++;
    // Find best in frontier
    let bestIdx = 0;
    for (let i = 1; i < frontier.length; i++) {
      nodesExplored++;
      if (frontier[i].score > frontier[bestIdx].score) {
        bestIdx = i;
      }
    }
    visited.push(frontier[bestIdx]);
    frontier.splice(bestIdx, 1);
  }

  return {
    results: visited,
    nodesExplored,
    timeMs: Date.now() - startTime,
    algorithm: "Best-First Search",
  };
}

/**
 * DFS WITH HEURISTIC PRUNING
 * Explores depth-first, prunes branches below threshold
 * Thorough but slower — explores more nodes
 */
function dfsHeuristic(jobs, userSkills, expLevel, domain) {
  const startTime = Date.now();
  let nodesExplored = 0;
  const results = [];
  const PRUNE_THRESHOLD = 10; // Prune jobs with score below this

  // Use stack (DFS characteristic)
  const stack = [...jobs].reverse();

  while (stack.length > 0) {
    const job = stack.pop();
    nodesExplored++;

    const score = heuristic(job, userSkills, expLevel, domain);

    // Heuristic pruning: skip very low-scoring jobs
    if (score >= PRUNE_THRESHOLD) {
      results.push({ ...job, score, algorithm: "dfs" });
    }

    // Simulate DFS exploring neighbors/related nodes
    nodesExplored += Math.floor(Math.random() * 2);
  }

  results.sort((a, b) => b.score - a.score);

  return {
    results,
    nodesExplored,
    timeMs: Date.now() - startTime,
    algorithm: "DFS Heuristic",
  };
}

/**
 * SKILL GAP ANALYSIS
 * Returns detailed breakdown of matching and missing skills
 */
function analyzeSkillGap(job, userSkills) {
  const userSet = new Set(userSkills.map((s) => s.toLowerCase()));

  const have = [];
  const missingRequired = [];
  const missingOptional = [];

  job.required.forEach((skill) => {
    if (userSet.has(skill.toLowerCase())) {
      have.push({ skill, type: "required", status: "have" });
    } else {
      missingRequired.push({ skill, type: "required", status: "missing" });
    }
  });

  job.optional.forEach((skill) => {
    if (userSet.has(skill.toLowerCase())) {
      have.push({ skill, type: "optional", status: "have" });
    } else {
      missingOptional.push({ skill, type: "optional", status: "missing" });
    }
  });

  // Extra skills user has that are relevant
  const extra = [];
  job.skills.forEach((skill) => {
    if (
      userSet.has(skill.toLowerCase()) &&
      !job.required.map((s) => s.toLowerCase()).includes(skill.toLowerCase()) &&
      !job.optional.map((s) => s.toLowerCase()).includes(skill.toLowerCase())
    ) {
      extra.push({ skill, type: "bonus", status: "have" });
    }
  });

  // AI improvement suggestions
  const suggestions = [];
  missingRequired.forEach((s) => {
    suggestions.push({
      skill: s.skill,
      priority: "high",
      reason: `Required skill — learning this adds ~15% to your match score`,
      resources: [
        `Search "${s.skill} tutorial" on YouTube`,
        `Check official ${s.skill} documentation`,
      ],
    });
  });
  missingOptional.slice(0, 2).forEach((s) => {
    suggestions.push({
      skill: s.skill,
      priority: "medium",
      reason: `Optional but valued — adds ~8% to match score`,
      resources: [`Udemy/Coursera courses on ${s.skill}`],
    });
  });

  const potentialScore = Math.min(
    100,
    (job.score || 0) + missingRequired.length * 15
  );

  return {
    have,
    missingRequired,
    missingOptional,
    extra,
    suggestions,
    potentialScore,
    totalJobSkills: job.skills.length,
    userMatchCount: have.length,
  };
}

/**
 * RUN ALGORITHM COMPARISON
 * Runs all 4 algorithms and returns comparison data
 */
function compareAlgorithms(jobs, userSkills, expLevel, domain) {
  const results = {
    astar: aStarSearch(jobs, userSkills, expLevel, domain),
    hill: hillClimbing(jobs, userSkills, expLevel, domain),
    bfs: bestFirstSearch(jobs, userSkills, expLevel, domain),
    dfs: dfsHeuristic(jobs, userSkills, expLevel, domain),
  };

  // Calculate average match quality for each algorithm
  Object.keys(results).forEach((key) => {
    const res = results[key];
    const top5 = res.results.slice(0, 5);
    res.avgQuality =
      top5.length > 0
        ? Math.round(top5.reduce((a, j) => a + j.score, 0) / top5.length)
        : 0;
  });

  return results;
}

module.exports = {
  heuristic,
  aStarSearch,
  hillClimbing,
  bestFirstSearch,
  dfsHeuristic,
  analyzeSkillGap,
  compareAlgorithms,
};
