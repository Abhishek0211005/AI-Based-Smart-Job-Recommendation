/**
 * NexusJobs AI - Backend Server
 * Express.js REST API
 */

const express = require("express");
const cors = require("cors");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const {
  aStarSearch,
  hillClimbing,
  bestFirstSearch,
  dfsHeuristic,
  analyzeSkillGap,
  compareAlgorithms,
} = require("./algorithms/jobAI");

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Multer setup for resume upload
const upload = multer({
  dest: "uploads/",
  fileFilter: (req, file, cb) => {
    const allowed = [".pdf", ".txt"];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowed.includes(ext)) cb(null, true);
    else cb(new Error("Only PDF and TXT files are allowed"));
  },
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
});

// Load job database
const JOBS_PATH = path.join(__dirname, "data", "jobs.json");
let jobsDB = JSON.parse(fs.readFileSync(JOBS_PATH, "utf-8"));

// ─────────────────────────────────────────────
// ROUTES
// ─────────────────────────────────────────────

// GET /api/jobs — return all jobs
app.get("/api/jobs", (req, res) => {
  res.json({ success: true, count: jobsDB.length, jobs: jobsDB });
});

// GET /api/skills — return all unique skills
app.get("/api/skills", (req, res) => {
  const skillSet = new Set();
  jobsDB.forEach((job) => job.skills.forEach((s) => skillSet.add(s)));
  res.json({ success: true, skills: [...skillSet].sort() });
});

// POST /api/recommend — main AI recommendation endpoint
app.post("/api/recommend", (req, res) => {
  const { skills, expLevel, domain, location, algorithm } = req.body;

  if (!skills || skills.length === 0) {
    return res
      .status(400)
      .json({ success: false, message: "Please provide at least one skill" });
  }

  // Filter by location if specified
  let filteredJobs = [...jobsDB];
  if (location && location !== "all") {
    filteredJobs = filteredJobs.filter((j) => j.location === location);
  }

  // Run selected algorithm
  let result;
  const algo = algorithm || "astar";

  switch (algo) {
    case "hill":
      result = hillClimbing(filteredJobs, skills, expLevel, domain);
      break;
    case "bfs":
      result = bestFirstSearch(filteredJobs, skills, expLevel, domain);
      break;
    case "dfs":
      result = dfsHeuristic(filteredJobs, skills, expLevel, domain);
      break;
    default:
      result = aStarSearch(filteredJobs, skills, expLevel, domain);
  }

  // Filter out 0-score jobs
  const topResults = result.results.filter((j) => j.score > 0);

  res.json({
    success: true,
    algorithm: result.algorithm,
    nodesExplored: result.nodesExplored,
    timeMs: result.timeMs,
    count: topResults.length,
    jobs: topResults,
  });
});

// POST /api/gap-analysis — skill gap for a specific job
app.post("/api/gap-analysis", (req, res) => {
  const { jobId, skills } = req.body;

  const job = jobsDB.find((j) => j.id === parseInt(jobId));
  if (!job) {
    return res
      .status(404)
      .json({ success: false, message: "Job not found" });
  }

  const gap = analyzeSkillGap(job, skills || []);
  res.json({ success: true, job: job.title, company: job.company, gap });
});

// POST /api/compare-algorithms — run all 4 algorithms and compare
app.post("/api/compare-algorithms", (req, res) => {
  const { skills, expLevel, domain } = req.body;

  if (!skills || skills.length === 0) {
    return res
      .status(400)
      .json({ success: false, message: "Skills required" });
  }

  const comparison = compareAlgorithms(jobsDB, skills, expLevel, domain);

  res.json({
    success: true,
    comparison: {
      astar: {
        name: "A* Search",
        timeMs: comparison.astar.timeMs,
        nodesExplored: comparison.astar.nodesExplored,
        avgQuality: comparison.astar.avgQuality,
        topJob: comparison.astar.results[0]?.title || "N/A",
        topScore: comparison.astar.results[0]?.score || 0,
      },
      hill: {
        name: "Hill Climbing",
        timeMs: comparison.hill.timeMs,
        nodesExplored: comparison.hill.nodesExplored,
        avgQuality: comparison.hill.avgQuality,
        topJob: comparison.hill.results[0]?.title || "N/A",
        topScore: comparison.hill.results[0]?.score || 0,
      },
      bfs: {
        name: "Best-First Search",
        timeMs: comparison.bfs.timeMs,
        nodesExplored: comparison.bfs.nodesExplored,
        avgQuality: comparison.bfs.avgQuality,
        topJob: comparison.bfs.results[0]?.title || "N/A",
        topScore: comparison.bfs.results[0]?.score || 0,
      },
      dfs: {
        name: "DFS Heuristic",
        timeMs: comparison.dfs.timeMs,
        nodesExplored: comparison.dfs.nodesExplored,
        avgQuality: comparison.dfs.avgQuality,
        topJob: comparison.dfs.results[0]?.title || "N/A",
        topScore: comparison.dfs.results[0]?.score || 0,
      },
    },
  });
});

// POST /api/upload-resume — parse resume and extract skills
app.post("/api/upload-resume", upload.single("resume"), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ success: false, message: "No file uploaded" });
  }

  try {
    let text = "";
    const filePath = req.file.path;
    const ext = path.extname(req.file.originalname).toLowerCase();

    if (ext === ".txt") {
      text = fs.readFileSync(filePath, "utf-8");
    } else if (ext === ".pdf") {
      // Try pdf-parse
      try {
        const pdfParse = require("pdf-parse");
        const dataBuffer = fs.readFileSync(filePath);
        const pdfData = await pdfParse(dataBuffer);
        text = pdfData.text;
      } catch (e) {
        // Fallback: return common extracted skills
        text = "";
      }
    }

    // NLP: extract known skills from text
    const allSkills = new Set();
    jobsDB.forEach((j) => j.skills.forEach((s) => allSkills.add(s)));

    const extractedSkills = [];
    allSkills.forEach((skill) => {
      if (text.toLowerCase().includes(skill.toLowerCase())) {
        extractedSkills.push(skill);
      }
    });

    // Clean up uploaded file
    fs.unlinkSync(filePath);

    res.json({
      success: true,
      extractedSkills,
      message: `Extracted ${extractedSkills.length} skills from resume`,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to parse resume" });
  }
});

// Health check
app.get("/api/health", (req, res) => {
  res.json({ success: true, message: "NexusJobs AI Backend running", port: PORT });
});

// Start server
app.listen(PORT, () => {
  console.log(`\n🚀 NexusJobs Backend running at http://localhost:${PORT}`);
  console.log(`📊 ${jobsDB.length} jobs loaded`);
  console.log(`\nAvailable endpoints:`);
  console.log(`  GET  /api/jobs`);
  console.log(`  GET  /api/skills`);
  console.log(`  POST /api/recommend`);
  console.log(`  POST /api/gap-analysis`);
  console.log(`  POST /api/compare-algorithms`);
  console.log(`  POST /api/upload-resume\n`);
});
