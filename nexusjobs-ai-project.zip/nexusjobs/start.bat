@echo off
echo Starting NexusJobs AI...
echo.

echo [1/2] Starting Backend on port 5000...
start cmd /k "cd backend && npm install && npm run dev"

timeout /t 3

echo [2/2] Starting Frontend on port 3000...
start cmd /k "cd frontend && npm install && npm start"

echo.
echo Both servers starting...
echo Backend: http://localhost:5000
echo Frontend: http://localhost:3000
