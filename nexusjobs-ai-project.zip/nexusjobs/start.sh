#!/bin/bash
echo "Starting NexusJobs AI..."

# Start backend
echo "Starting backend on port 5000..."
cd backend
npm install
npm run dev &
BACKEND_PID=$!

cd ..

# Wait a moment
sleep 2

# Start frontend
echo "Starting frontend on port 3000..."
cd frontend
npm install
npm start &
FRONTEND_PID=$!

echo ""
echo "Backend: http://localhost:5000"
echo "Frontend: http://localhost:3000"
echo ""
echo "Press Ctrl+C to stop both servers"

# Wait for Ctrl+C
trap "kill $BACKEND_PID $FRONTEND_PID; exit" INT
wait
