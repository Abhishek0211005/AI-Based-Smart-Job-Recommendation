import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:5000/api",
  timeout: 10000,
});

export const fetchJobs = () => API.get("/jobs");
export const fetchSkills = () => API.get("/skills");

export const getRecommendations = (payload) =>
  API.post("/recommend", payload);

export const getGapAnalysis = (jobId, skills) =>
  API.post("/gap-analysis", { jobId, skills });

export const compareAlgorithms = (payload) =>
  API.post("/compare-algorithms", payload);

export const uploadResume = (file) => {
  const formData = new FormData();
  formData.append("resume", file);
  return API.post("/upload-resume", formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
};

export default API;
