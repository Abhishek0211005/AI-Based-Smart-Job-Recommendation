// Local fallback — runs AI algorithms in browser if backend is down
const JOBS = [
  { id:1, title:"Senior React Developer", company:"TechCorp", logo:"TC", logoColor:"#4F8EF7", domain:"web", skills:["React","JavaScript","TypeScript","Node.js","CSS","Redux","GraphQL"], required:["React","JavaScript"], optional:["TypeScript","Redux","GraphQL"], salary:"$95k–$130k", salaryMin:95000, salaryMax:130000, location:"remote", type:"Full-time", description:"Build scalable frontends for millions of users.", experience:["intermediate","experienced"], postedDays:2 },
  { id:2, title:"ML Engineer", company:"DataVision", logo:"DV", logoColor:"#7C3AED", domain:"data", skills:["Python","TensorFlow","PyTorch","SQL","NumPy","Pandas","Scikit-learn"], required:["Python","TensorFlow"], optional:["PyTorch","Scikit-learn"], salary:"$110k–$155k", salaryMin:110000, salaryMax:155000, location:"hybrid", type:"Full-time", description:"Design and deploy production ML pipelines.", experience:["intermediate","experienced"], postedDays:5 },
  { id:3, title:"Full Stack Developer", company:"Nexus Labs", logo:"NL", logoColor:"#10B981", domain:"web", skills:["React","Node.js","MongoDB","JavaScript","Express","Docker","Redis"], required:["React","Node.js","JavaScript"], optional:["MongoDB","Docker"], salary:"$80k–$110k", salaryMin:80000, salaryMax:110000, location:"remote", type:"Full-time", description:"End-to-end product development.", experience:["fresher","intermediate"], postedDays:1 },
  { id:4, title:"Data Scientist", company:"AnalyticsPro", logo:"AP", logoColor:"#F59E0B", domain:"data", skills:["Python","R","SQL","Pandas","Machine Learning","Statistics","Tableau"], required:["Python","SQL"], optional:["R","Machine Learning"], salary:"$90k–$125k", salaryMin:90000, salaryMax:125000, location:"hybrid", type:"Full-time", description:"Extract insights from large datasets.", experience:["intermediate","experienced"], postedDays:3 },
  { id:5, title:"DevOps Engineer", company:"CloudScale", logo:"CS", logoColor:"#06B6D4", domain:"devops", skills:["Docker","Kubernetes","AWS","Terraform","Python","Linux","CI/CD"], required:["Docker","Kubernetes"], optional:["AWS","Terraform"], salary:"$100k–$140k", salaryMin:100000, salaryMax:140000, location:"remote", type:"Full-time", description:"Build cloud infrastructure.", experience:["intermediate","experienced"], postedDays:7 },
  { id:6, title:"Junior Frontend Developer", company:"StartupHub", logo:"SH", logoColor:"#F472B6", domain:"web", skills:["HTML","CSS","JavaScript","React","Git","Figma"], required:["HTML","CSS","JavaScript"], optional:["React","Git"], salary:"$50k–$75k", salaryMin:50000, salaryMax:75000, location:"hybrid", type:"Full-time", description:"Build beautiful UIs.", experience:["fresher","intermediate"], postedDays:1 },
  { id:7, title:"Backend Engineer", company:"ServerSide Co", logo:"SS", logoColor:"#8B5CF6", domain:"backend", skills:["Python","Django","PostgreSQL","Redis","REST APIs","Docker","Kafka"], required:["Python","Django"], optional:["PostgreSQL","Redis"], salary:"$88k–$120k", salaryMin:88000, salaryMax:120000, location:"remote", type:"Full-time", description:"Design high-performance APIs.", experience:["intermediate","experienced"], postedDays:6 },
  { id:8, title:"Android Developer", company:"MobileFirst", logo:"MF", logoColor:"#EF4444", domain:"mobile", skills:["Kotlin","Java","Android SDK","Firebase","REST APIs","Jetpack","MVVM"], required:["Kotlin","Java"], optional:["Firebase","Jetpack"], salary:"$85k–$120k", salaryMin:85000, salaryMax:120000, location:"onsite", type:"Full-time", description:"Build mobile apps for 10M+ users.", experience:["intermediate","experienced"], postedDays:4 },
];

function heuristic(job, userSkills, expLevel, domain) {
  const userSet = new Set(userSkills.map(s => s.toLowerCase()));
  const req = job.required.map(s => s.toLowerCase());
  const opt = job.optional.map(s => s.toLowerCase());
  let reqMatch = req.filter(s => userSet.has(s)).length;
  let optMatch = opt.filter(s => userSet.has(s)).length;
  let score = (req.length > 0 ? reqMatch/req.length : 0) * 60 + (opt.length > 0 ? optMatch/opt.length : 0) * 25;
  if (job.experience.includes(expLevel)) score += 5;
  if (domain && domain !== 'all' && job.domain === domain) score += 5;
  return Math.min(Math.round(score), 100);
}

export function localRecommend({ skills, expLevel, domain, location, algorithm }) {
  let jobs = [...JOBS];
  if (location && location !== 'all') jobs = jobs.filter(j => j.location === location);
  
  const scored = jobs.map(j => ({
    ...j,
    score: heuristic(j, skills, expLevel, domain),
    algo: algorithm || 'astar',
    algorithm: algorithm || 'astar',
  })).filter(j => j.score > 0).sort((a, b) => b.score - a.score);
  
  return scored;
}
