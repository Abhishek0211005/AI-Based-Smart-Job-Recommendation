import React from "react";

const ALGO_LABELS = { astar: "A*", hill: "Hill", bfs: "BFS", dfs: "DFS" };

export default function JobCard({ job, rank, userSkills, savedJobs, onSelect, onSave, onApply, selected }) {
  const userSet = new Set((userSkills || []).map((s) => s.toLowerCase()));
  const pct = job.score || 0;
  const color = pct >= 75 ? "var(--green)" : pct >= 50 ? "var(--amber)" : "var(--red)";
  const algo = job.algorithm?.replace("astar", "astar").replace("Best-First Search", "bfs")
    .replace("A* Search", "astar").replace("Hill Climbing", "hill").replace("DFS Heuristic", "dfs") || "astar";
  const algoKey = job.algo || algo;
  const isSaved = savedJobs?.has(job.id);

  return (
    <div className={`job-card ${selected ? "selected" : ""}`} onClick={() => onSelect(job)}>
      <span className="rank-badge">{rank}</span>
      <span className={`algo-tag ${algoKey}`}>{ALGO_LABELS[algoKey] || "A*"}</span>

      <div className="job-header">
        <div className="job-title-row">
          <div className="company-logo" style={{ background: job.logoColor + "22", color: job.logoColor }}>
            {job.logo}
          </div>
          <div>
            <div className="job-title">{job.title}</div>
            <div className="job-company">
              {job.company}
              <span className="domain-badge">{job.domain}</span>
            </div>
          </div>
        </div>
        <div className="match-badge">
          <div className="match-pct" style={{ color }}>{pct}%</div>
          <div className="match-label">match</div>
        </div>
      </div>

      <div className="match-bar">
        <div className="match-fill" style={{ width: pct + "%", background: color }} />
      </div>

      <div className="job-meta">
        <span className="job-meta-item">📍 {job.location}</span>
        <span className="dot" />
        <span className="job-meta-item">💼 {job.type}</span>
        <span className="dot" />
        <span className="job-meta-item">⏱ Posted {job.postedDays}d ago</span>
      </div>

      <div className="skill-pills">
        {(job.required || []).map((s) => (
          <span key={s} className={`skill-pill ${userSet.has(s.toLowerCase()) ? "have" : "missing"}`}>{s}</span>
        ))}
        {(job.optional || []).slice(0, 2).map((s) => (
          <span key={s} className={`skill-pill ${userSet.has(s.toLowerCase()) ? "have" : "optional"}`}>{s}</span>
        ))}
      </div>

      <div className="job-footer">
        <div className="job-salary">{job.salary}</div>
        <div className="job-actions">
          <button
            className={`btn-sm btn-save ${isSaved ? "saved" : ""}`}
            onClick={(e) => { e.stopPropagation(); onSave(job); }}
          >
            {isSaved ? "★ Saved" : "☆ Save"}
          </button>
          <button
            className="btn-sm btn-apply-sm"
            onClick={(e) => { e.stopPropagation(); onApply(job); }}
          >
            Apply Now
          </button>
        </div>
      </div>
    </div>
  );
}
