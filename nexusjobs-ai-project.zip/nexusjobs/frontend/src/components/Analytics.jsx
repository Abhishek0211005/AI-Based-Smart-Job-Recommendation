import React, { useEffect, useRef } from "react";
import {
  Chart as ChartJS,
  CategoryScale, LinearScale, BarElement, ArcElement,
  RadialLinearScale, PointElement, LineElement,
  Tooltip, Legend, Title,
} from "chart.js";
import { Bar, Doughnut } from "react-chartjs-2";

ChartJS.register(
  CategoryScale, LinearScale, BarElement, ArcElement,
  RadialLinearScale, PointElement, LineElement,
  Tooltip, Legend, Title
);

const CHART_DEFAULTS = {
  color: "#8B95A8",
  plugins: { legend: { display: false } },
  scales: {
    x: { ticks: { color: "#8B95A8", font: { size: 10 } }, grid: { color: "#2A3448" } },
    y: { ticks: { color: "#8B95A8" }, grid: { color: "#2A3448" } },
  },
};

export default function Analytics({ jobs }) {
  if (!jobs || jobs.length === 0) {
    return (
      <div className="empty-state">
        <div className="empty-icon">📈</div>
        <div className="empty-title">Run recommendations to see analytics</div>
        <div className="empty-sub">Charts will appear here showing match scores, salary distribution, and skill coverage.</div>
      </div>
    );
  }

  const top8 = jobs.slice(0, 8);
  const high = jobs.filter((j) => j.score >= 75).length;
  const mid = jobs.filter((j) => j.score >= 50 && j.score < 75).length;
  const low = jobs.filter((j) => j.score < 50).length;
  const top6 = jobs.slice(0, 6);

  const matchChartData = {
    labels: top8.map((j) => j.title.split(" ").slice(0, 2).join(" ")),
    datasets: [{
      label: "Match %",
      data: top8.map((j) => j.score),
      backgroundColor: top8.map((j) => j.score >= 75 ? "#10B98180" : j.score >= 50 ? "#F59E0B80" : "#EF444480"),
      borderColor: top8.map((j) => j.score >= 75 ? "#10B981" : j.score >= 50 ? "#F59E0B" : "#EF4444"),
      borderWidth: 1,
      borderRadius: 5,
    }],
  };

  const donutData = {
    labels: ["High match (75%+)", "Medium (50–74%)", "Low (<50%)"],
    datasets: [{
      data: [high, mid, low],
      backgroundColor: ["#10B981", "#F59E0B", "#EF4444"],
      borderWidth: 0,
    }],
  };

  const salaryData = {
    labels: top6.map((j) => j.title.split(" ").slice(0, 2).join(" ")),
    datasets: [{
      label: "Avg Salary ($k)",
      data: top6.map((j) => Math.round((j.salaryMin + j.salaryMax) / 2 / 1000)),
      backgroundColor: "#4F8EF780",
      borderColor: "#4F8EF7",
      borderWidth: 1,
      borderRadius: 4,
    }],
  };

  const locationCounts = {};
  jobs.forEach((j) => { locationCounts[j.location] = (locationCounts[j.location] || 0) + 1; });
  const locationData = {
    labels: Object.keys(locationCounts),
    datasets: [{
      data: Object.values(locationCounts),
      backgroundColor: ["#4F8EF7", "#10B981", "#F59E0B"],
      borderWidth: 0,
    }],
  };

  return (
    <div>
      {/* Summary row */}
      <div className="stats-row" style={{ marginBottom: 20 }}>
        <div className="stat-card">
          <div className="stat-num" style={{ background: "var(--grad)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>{jobs.length}</div>
          <div className="stat-label">Jobs Matched</div>
        </div>
        <div className="stat-card">
          <div className="stat-num" style={{ color: "var(--green)" }}>{high}</div>
          <div className="stat-label">High Match (75%+)</div>
        </div>
        <div className="stat-card">
          <div className="stat-num" style={{ color: "var(--amber)" }}>
            {jobs.length > 0 ? Math.round(jobs.reduce((a, j) => a + j.score, 0) / jobs.length) : 0}%
          </div>
          <div className="stat-label">Avg Match Score</div>
        </div>
        <div className="stat-card">
          <div className="stat-num" style={{ color: "var(--accent)" }}>{jobs[0]?.score || 0}%</div>
          <div className="stat-label">Top Match</div>
        </div>
      </div>

      {/* Match scores */}
      <div className="chart-wrap">
        <div className="chart-title">Match score by job (top 8)</div>
        <div style={{ position: "relative", height: 240 }}>
          <Bar data={matchChartData} options={{
            ...CHART_DEFAULTS,
            responsive: true,
            maintainAspectRatio: false,
            scales: {
              x: { ticks: { color: "#8B95A8", font: { size: 10 }, maxRotation: 30 }, grid: { color: "#2A3448" } },
              y: { ticks: { color: "#8B95A8", callback: (v) => v + "%" }, grid: { color: "#2A3448" }, max: 100 },
            },
          }} />
        </div>
      </div>

      {/* Donut + Salary */}
      <div className="charts-2col">
        <div className="chart-wrap">
          <div className="chart-title">Match distribution</div>
          <div className="chart-legend">
            <span><span className="legend-dot" style={{ background: "#10B981" }} />High 75%+</span>
            <span><span className="legend-dot" style={{ background: "#F59E0B" }} />Medium</span>
            <span><span className="legend-dot" style={{ background: "#EF4444" }} />Low</span>
          </div>
          <div style={{ position: "relative", height: 180 }}>
            <Doughnut data={donutData} options={{
              responsive: true,
              maintainAspectRatio: false,
              plugins: { legend: { display: false } },
              cutout: "65%",
            }} />
          </div>
        </div>

        <div className="chart-wrap">
          <div className="chart-title">Salary range — top 6 jobs ($k)</div>
          <div style={{ position: "relative", height: 210 }}>
            <Bar data={salaryData} options={{
              responsive: true,
              maintainAspectRatio: false,
              plugins: { legend: { display: false } },
              scales: {
                x: { ticks: { color: "#8B95A8", font: { size: 10 }, maxRotation: 30 }, grid: { color: "#2A3448" } },
                y: { ticks: { color: "#8B95A8", callback: (v) => "$" + v + "k" }, grid: { color: "#2A3448" } },
              },
            }} />
          </div>
        </div>
      </div>

      {/* Location */}
      <div className="chart-wrap">
        <div className="chart-title">Jobs by location type</div>
        <div className="chart-legend">
          {Object.keys(locationCounts).map((loc, i) => (
            <span key={loc}><span className="legend-dot" style={{ background: ["#4F8EF7","#10B981","#F59E0B"][i] }} />{loc} ({locationCounts[loc]})</span>
          ))}
        </div>
        <div style={{ position: "relative", height: 180 }}>
          <Doughnut data={locationData} options={{
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            cutout: "55%",
          }} />
        </div>
      </div>
    </div>
  );
}
