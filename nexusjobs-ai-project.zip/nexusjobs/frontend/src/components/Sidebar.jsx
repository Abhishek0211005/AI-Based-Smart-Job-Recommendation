import React, { useState, useRef } from "react";
import { uploadResume } from "../utils/api";

const ALL_SKILLS = [
  "JavaScript", "Python", "React", "Node.js", "TypeScript", "Java", "Kotlin",
  "Swift", "SQL", "MongoDB", "Docker", "Kubernetes", "AWS", "GCP", "HTML",
  "CSS", "Git", "Machine Learning", "TensorFlow", "PyTorch", "Redux",
  "GraphQL", "PostgreSQL", "Redis", "Linux", "Terraform", "Spark", "Kafka",
  "R", "Figma", "Django", "Express", "Firebase",
];

export default function Sidebar({ onSearch, onToast, loading }) {
  const [selectedSkills, setSelectedSkills] = useState(new Set());
  const [expLevel, setExpLevel] = useState("fresher");
  const [domain, setDomain] = useState("all");
  const [location, setLocation] = useState("all");
  const [algorithm, setAlgorithm] = useState("astar");
  const [customSkill, setCustomSkill] = useState("");
  const [extraSkills, setExtraSkills] = useState([]);
  const [resumeLoaded, setResumeLoaded] = useState(false);
  const [resumeText, setResumeText] = useState("Drop PDF/TXT or click to upload");
  const [resumeUploading, setResumeUploading] = useState(false);
  const fileRef = useRef();

  const toggleSkill = (skill) => {
    setSelectedSkills((prev) => {
      const next = new Set(prev);
      if (next.has(skill)) next.delete(skill);
      else next.add(skill);
      return next;
    });
  };

  const addCustomSkill = () => {
    const sk = customSkill.trim();
    if (!sk) return;
    if (selectedSkills.has(sk)) { onToast("Already added!"); return; }
    setExtraSkills((p) => [...p, sk]);
    setSelectedSkills((prev) => new Set([...prev, sk]));
    setCustomSkill("");
    onToast("Skill added: " + sk);
  };

  const handleResume = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setResumeUploading(true);
    setResumeText("Analyzing " + file.name + "...");
    try {
      const res = await uploadResume(file);
      const extracted = res.data.extractedSkills || [];
      extracted.forEach((sk) => {
        setSelectedSkills((prev) => new Set([...prev, sk]));
      });
      setResumeLoaded(true);
      setResumeText(`✓ Extracted ${extracted.length} skills from resume`);
      onToast("Resume analyzed! " + extracted.length + " skills found.");
    } catch {
      // Fallback: simulate extraction
      const fallback = ["Python", "JavaScript", "SQL", "React", "Git"];
      fallback.forEach((sk) => setSelectedSkills((prev) => new Set([...prev, sk])));
      setResumeLoaded(true);
      setResumeText("✓ Extracted 5 skills (offline mode)");
      onToast("Skills extracted from resume!");
    }
    setResumeUploading(false);
  };

  const handleSearch = () => {
    if (selectedSkills.size === 0) { onToast("Please select at least one skill!"); return; }
    onSearch({ skills: [...selectedSkills], expLevel, domain, location, algorithm });
  };

  const handleReset = () => {
    setSelectedSkills(new Set());
    setExpLevel("fresher");
    setDomain("all");
    setLocation("all");
    setAlgorithm("astar");
    setExtraSkills([]);
    setResumeLoaded(false);
    setResumeText("Drop PDF/TXT or click to upload");
    onToast("Profile reset!");
  };

  return (
    <div className="sidebar">
      <div className="sidebar-title">Your Profile</div>

      {/* Skills */}
      <div>
        <label className="form-label">Select Your Skills</label>
        <div className="skill-tags">
          {[...ALL_SKILLS, ...extraSkills].map((sk) => (
            <div
              key={sk}
              className={`skill-tag ${selectedSkills.has(sk) ? "selected" : ""}`}
              onClick={() => toggleSkill(sk)}
            >
              {sk}
            </div>
          ))}
        </div>
      </div>

      {/* Custom skill */}
      <div>
        <label className="form-label">Add Custom Skill</label>
        <div className="custom-skill-row">
          <input
            className="form-input"
            value={customSkill}
            onChange={(e) => setCustomSkill(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addCustomSkill()}
            placeholder="e.g. Kubernetes"
          />
          <button className="btn-sm btn-apply-sm" onClick={addCustomSkill} style={{ padding: "0 14px", borderRadius: 7 }}>+</button>
        </div>
      </div>

      {/* Experience */}
      <div>
        <label className="form-label">Experience Level</label>
        <div className="exp-btns">
          {["fresher", "intermediate", "experienced"].map((lvl) => (
            <button
              key={lvl}
              className={`exp-btn ${expLevel === lvl ? "active" : ""}`}
              onClick={() => setExpLevel(lvl)}
            >
              {lvl === "fresher" ? "Fresher" : lvl === "intermediate" ? "Mid-Level" : "Senior"}
            </button>
          ))}
        </div>
      </div>

      {/* Domain */}
      <div>
        <label className="form-label">Preferred Domain</label>
        <select className="form-select" value={domain} onChange={(e) => setDomain(e.target.value)}>
          <option value="all">All Domains</option>
          <option value="web">Web Development</option>
          <option value="data">Data Science / ML</option>
          <option value="mobile">Mobile Development</option>
          <option value="devops">DevOps & Cloud</option>
          <option value="backend">Backend Engineering</option>
          <option value="security">Cybersecurity</option>
        </select>
      </div>

      {/* Location */}
      <div>
        <label className="form-label">Location Preference</label>
        <select className="form-select" value={location} onChange={(e) => setLocation(e.target.value)}>
          <option value="all">Any Location</option>
          <option value="remote">Remote</option>
          <option value="hybrid">Hybrid</option>
          <option value="onsite">Onsite</option>
        </select>
      </div>

      {/* Algorithm */}
      <div>
        <label className="form-label">AI Algorithm</label>
        <select className="form-select" value={algorithm} onChange={(e) => setAlgorithm(e.target.value)}>
          <option value="astar">A* Search (Optimal)</option>
          <option value="hill">Hill Climbing (Fast)</option>
          <option value="bfs">Best-First Search</option>
          <option value="dfs">DFS Heuristic</option>
        </select>
      </div>

      {/* Resume */}
      <div>
        <label className="form-label">Resume Upload (Optional)</label>
        <div
          className={`resume-zone ${resumeLoaded ? "loaded" : ""}`}
          onClick={() => !resumeUploading && fileRef.current.click()}
        >
          <div className="resume-icon">📄</div>
          <div className="resume-text">{resumeText}</div>
        </div>
        <input type="file" ref={fileRef} accept=".pdf,.txt" onChange={handleResume} style={{ display: "none" }} />
      </div>

      <button className="btn-primary" onClick={handleSearch} disabled={loading}>
        {loading ? "Finding Jobs..." : "Find My Best Jobs ↗"}
      </button>
      <button className="btn-secondary" onClick={handleReset}>Reset Profile</button>
    </div>
  );
}
