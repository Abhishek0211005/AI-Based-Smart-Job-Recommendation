import React from "react";

export default function GapAnalysis({ job, gapData, userSkills }) {
  if (!job) {
    return (
      <div className="empty-state">
        <div className="empty-icon">📊</div>
        <div className="empty-title">Select a job to analyze</div>
        <div className="empty-sub">Click any job card to see detailed skill gap analysis and AI-powered improvement suggestions.</div>
      </div>
    );
  }

  const userSet = new Set((userSkills || []).map((s) => s.toLowerCase()));
  const pct = job.score || 0;
  const color = pct >= 75 ? "var(--green)" : pct >= 50 ? "var(--amber)" : "var(--red)";

  // Use backend gap data if available, else compute locally
  const have = gapData?.have || job.required.filter((s) => userSet.has(s.toLowerCase())).map((s) => ({ skill: s, type: "required" }));
  const missingRequired = gapData?.missingRequired || job.required.filter((s) => !userSet.has(s.toLowerCase())).map((s) => ({ skill: s, type: "required" }));
  const missingOptional = gapData?.missingOptional || job.optional.filter((s) => !userSet.has(s.toLowerCase())).map((s) => ({ skill: s, type: "optional" }));
  const suggestions = gapData?.suggestions || missingRequired.slice(0, 3).map((s) => ({
    skill: s.skill,
    priority: "high",
    reason: `Required — adds ~15% to match score`,
  }));

  const potentialScore = Math.min(100, pct + missingRequired.length * 15);

  return (
    <div>
      {/* Header */}
      <div className="gap-panel">
        <div className="gap-panel-title">
          <span>📊</span>
          Skill Gap — {job.title} at {job.company}
          <span style={{ marginLeft: "auto", color, fontFamily: "'Syne', sans-serif", fontWeight: 700 }}>
            {pct}% match
          </span>
        </div>

        <div className="gap-grid">
          {/* Have */}
          <div className="gap-section">
            <h4>Skills you have ({have.length})</h4>
            {have.length === 0 && <div className="gap-skill missing">No matching skills</div>}
            {have.map((s) => (
              <div key={s.skill} className="gap-skill have">
                ✓ {s.skill}
                <span style={{ fontSize: 10, opacity: 0.7 }}>{s.type}</span>
              </div>
            ))}
          </div>

          {/* Missing */}
          <div className="gap-section">
            <h4>Skills you need ({missingRequired.length + missingOptional.length})</h4>
            {missingRequired.length === 0 && missingOptional.length === 0 && (
              <div className="gap-skill have">You have all required skills! 🎉</div>
            )}
            {missingRequired.map((s) => (
              <div key={s.skill} className="gap-skill missing">
                ✗ {s.skill}
                <span style={{ fontSize: 10, opacity: 0.7 }}>required</span>
              </div>
            ))}
            {missingOptional.map((s) => (
              <div key={s.skill} className="gap-skill optional">
                ~ {s.skill}
                <span style={{ fontSize: 10, opacity: 0.7 }}>optional</span>
              </div>
            ))}
          </div>
        </div>

        {/* Potential score */}
        {missingRequired.length > 0 && (
          <div style={{ marginTop: 12, fontSize: 13, color: "var(--text2)" }}>
            📈 If you learn required skills, your score could reach{" "}
            <strong style={{ color: "var(--green)" }}>{potentialScore}%</strong>
          </div>
        )}
      </div>

      {/* Suggestions */}
      {suggestions.length > 0 && (
        <div className="gap-panel">
          <div className="gap-panel-title"><span>💡</span> AI Improvement Suggestions</div>
          <div className="suggestion-box">
            {suggestions.map((s, i) => (
              <div key={s.skill} style={{ marginBottom: 10 }}>
                <span style={{ color: s.priority === "high" ? "var(--red)" : "var(--amber)", fontWeight: 500 }}>
                  {i + 1}. Learn <strong style={{ color: "var(--text)" }}>{s.skill}</strong>
                </span>
                <span style={{ color: "var(--text3)" }}> — {s.reason}</span>
                {s.resources && (
                  <div style={{ fontSize: 11, color: "var(--text3)", marginTop: 3, paddingLeft: 14 }}>
                    {s.resources.map((r, ri) => <div key={ri}>→ {r}</div>)}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Job description */}
      <div className="gap-panel">
        <div className="gap-panel-title"><span>📝</span> Job Description</div>
        <p style={{ fontSize: 13, color: "var(--text2)", lineHeight: 1.8 }}>{job.description}</p>
        <div style={{ marginTop: 12 }}>
          <div style={{ fontSize: 11, color: "var(--text3)", marginBottom: 8 }}>All required skills:</div>
          <div className="skill-pills">
            {(job.skills || []).map((s) => {
              const has = userSet.has(s.toLowerCase());
              const isReq = job.required.map((r) => r.toLowerCase()).includes(s.toLowerCase());
              return (
                <span key={s} className={`skill-pill ${has ? "have" : isReq ? "missing" : "optional"}`}>{s}</span>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
