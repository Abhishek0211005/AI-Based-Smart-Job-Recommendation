import React, { useState, useCallback } from "react";
import "./App.css";
import Sidebar from "./components/Sidebar";
import JobCard from "./components/JobCard";
import GapAnalysis from "./components/GapAnalysis";
import Analytics from "./components/Analytics";
import AlgoLab from "./pages/AlgoLab";
import { getRecommendations, getGapAnalysis } from "./utils/api";

const ALGO_NAMES = {
  astar: "A* Search",
  hill: "Hill Climbing",
  bfs: "Best-First Search",
  dfs: "DFS Heuristic",
};

export default function App() {
  const [view, setView] = useState("jobs"); // jobs | algo | saved
  const [contentTab, setContentTab] = useState("results"); // results | gap | viz
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedJob, setSelectedJob] = useState(null);
  const [gapData, setGapData] = useState(null);
  const [savedJobs, setSavedJobs] = useState(new Set());
  const [filterMode, setFilterMode] = useState("all");
  const [sortMode, setSortMode] = useState("match");
  const [toast, setToast] = useState({ show: false, msg: "" });
  const [stats, setStats] = useState(null);
  const [userProfile, setUserProfile] = useState({ skills: [], expLevel: "fresher" });
  const [algoName, setAlgoName] = useState("A* Search");

  const showToast = useCallback((msg) => {
    setToast({ show: true, msg });
    setTimeout(() => setToast({ show: false, msg: "" }), 2800);
  }, []);

  // Run AI recommendations
  const handleSearch = async (profile) => {
    setLoading(true);
    setJobs([]);
    setSelectedJob(null);
    setGapData(null);
    setUserProfile({ skills: profile.skills, expLevel: profile.expLevel });
    setAlgoName(ALGO_NAMES[profile.algorithm] || "A* Search");
    setContentTab("results");

    try {
      const res = await getRecommendations(profile);
      const data = res.data;
      const results = data.jobs || [];
      setJobs(results);
      setStats({
        total: results.length,
        avg: results.length > 0 ? Math.round(results.reduce((a, j) => a + j.score, 0) / results.length) : 0,
        top: results[0]?.score || 0,
        nodes: data.nodesExplored || 0,
        time: data.timeMs || 0,
        algo: data.algorithm || profile.algorithm,
      });
      if (results.length > 0) {
        setSelectedJob(results[0]);
        fetchGap(results[0].id, profile.skills);
      }
      showToast(`Found ${results.length} jobs using ${data.algorithm || "A*"}`);
    } catch (err) {
      showToast("Backend not running — showing sample results");
      // Fallback: local mock
      import("./utils/localFallback").then((m) => {
        const results = m.localRecommend(profile);
        setJobs(results);
        setStats({ total: results.length, avg: Math.round(results.reduce((a,j)=>a+j.score,0)/results.length), top: results[0]?.score||0, nodes: 42, time: 12, algo: "A*" });
        if (results.length > 0) setSelectedJob(results[0]);
      });
    }
    setLoading(false);
  };

  const fetchGap = async (jobId, skills) => {
    try {
      const res = await getGapAnalysis(jobId, skills);
      if (res.data.success) setGapData(res.data.gap);
    } catch { /* gap computed locally in component */ }
  };

  const handleSelectJob = (job) => {
    setSelectedJob(job);
    setContentTab("gap");
    fetchGap(job.id, userProfile.skills);
  };

  const handleSave = (job) => {
    setSavedJobs((prev) => {
      const next = new Set(prev);
      if (next.has(job.id)) { next.delete(job.id); showToast("Removed from saved"); }
      else { next.add(job.id); showToast("Job saved!"); }
      return next;
    });
  };

  const handleApply = (job) => {
    showToast(`Applied to ${job.title} at ${job.company}! 🎉`);
  };

  // Filter + sort
  const filtered = (() => {
    let list = [...jobs];
    if (filterMode === "remote") list = list.filter((j) => j.location === "remote");
    else if (filterMode === "hybrid") list = list.filter((j) => j.location === "hybrid");
    else if (filterMode === "high") list = list.filter((j) => j.score >= 75);
    else if (filterMode === "saved") list = list.filter((j) => savedJobs.has(j.id));
    if (sortMode === "salary") list.sort((a, b) => (b.salaryMax - a.salaryMax));
    else if (sortMode === "alpha") list.sort((a, b) => a.title.localeCompare(b.title));
    else list.sort((a, b) => b.score - a.score);
    return list;
  })();

  const savedList = jobs.filter((j) => savedJobs.has(j.id));

  return (
    <div className="app">
      {/* Navbar */}
      <nav className="navbar">
        <div className="logo">NexusJobs AI</div>
        <div className="nav-tabs">
          {["jobs", "algo", "saved"].map((v) => (
            <button key={v} className={`nav-tab ${view === v ? "active" : ""}`} onClick={() => setView(v)}>
              {v === "jobs" ? "Find Jobs" : v === "algo" ? "Algorithm Lab" : `Saved (${savedJobs.size})`}
            </button>
          ))}
        </div>
        <div className="algo-badge">{algoName}</div>
      </nav>

      {/* JOBS VIEW */}
      {view === "jobs" && (
        <div className="main-layout" style={{ flex: 1, overflow: "hidden" }}>
          <Sidebar onSearch={handleSearch} onToast={showToast} loading={loading} />

          <div className="content">
            <div className="content-tabs">
              {["results", "gap", "viz"].map((t) => (
                <button key={t} className={`content-tab ${contentTab === t ? "active" : ""}`} onClick={() => setContentTab(t)}>
                  {t === "results" ? "Recommendations" : t === "gap" ? "Skill Gap Analysis" : "Visual Analytics"}
                </button>
              ))}
            </div>

            <div className="content-body">
              {/* RESULTS TAB */}
              {contentTab === "results" && (
                <>
                  {loading && (
                    <div className="loading-wrap">
                      <div className="spinner" />
                      <div className="loading-text">Running {algoName} algorithm...</div>
                    </div>
                  )}

                  {!loading && jobs.length > 0 && (
                    <>
                      {/* Stats */}
                      <div className="stats-row">
                        <div className="stat-card">
                          <div className="stat-num" style={{ background: "var(--grad)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                            {stats?.total}
                          </div>
                          <div className="stat-label">Jobs Found</div>
                        </div>
                        <div className="stat-card">
                          <div className="stat-num" style={{ color: "var(--green)" }}>{stats?.avg}%</div>
                          <div className="stat-label">Avg Match Score</div>
                        </div>
                        <div className="stat-card">
                          <div className="stat-num" style={{ color: "var(--accent)" }}>{stats?.top}%</div>
                          <div className="stat-label">Top Match</div>
                        </div>
                        <div className="stat-card">
                          <div className="stat-num" style={{ color: "var(--amber)" }}>{stats?.nodes}</div>
                          <div className="stat-label">Nodes Explored</div>
                        </div>
                      </div>

                      {/* Filters */}
                      <div className="filter-bar">
                        {["all", "remote", "hybrid", "high", "saved"].map((f) => (
                          <button key={f} className={`filter-chip ${filterMode === f ? "active" : ""}`} onClick={() => setFilterMode(f)}>
                            {f === "all" ? "All" : f === "remote" ? "Remote" : f === "hybrid" ? "Hybrid" : f === "high" ? "High Match 75%+" : `Saved (${savedJobs.size})`}
                          </button>
                        ))}
                        <select className="sort-select" value={sortMode} onChange={(e) => setSortMode(e.target.value)}>
                          <option value="match">Sort: Match %</option>
                          <option value="salary">Sort: Salary</option>
                          <option value="alpha">Sort: Name A–Z</option>
                        </select>
                      </div>

                      {/* Job cards */}
                      <div className="jobs-grid">
                        {filtered.map((job, i) => (
                          <JobCard
                            key={job.id}
                            job={job}
                            rank={i + 1}
                            userSkills={userProfile.skills}
                            savedJobs={savedJobs}
                            onSelect={handleSelectJob}
                            onSave={handleSave}
                            onApply={handleApply}
                            selected={selectedJob?.id === job.id}
                          />
                        ))}
                        {filtered.length === 0 && (
                          <div style={{ textAlign: "center", padding: 40, color: "var(--text3)" }}>No jobs match this filter.</div>
                        )}
                      </div>
                    </>
                  )}

                  {!loading && jobs.length === 0 && (
                    <div className="empty-state">
                      <div className="empty-icon">🔍</div>
                      <div className="empty-title">Ready to find your perfect job?</div>
                      <div className="empty-sub">Select your skills on the left and hit "Find My Best Jobs" to get AI-powered recommendations ranked by compatibility.</div>
                    </div>
                  )}
                </>
              )}

              {/* GAP TAB */}
              {contentTab === "gap" && (
                <GapAnalysis job={selectedJob} gapData={gapData} userSkills={userProfile.skills} />
              )}

              {/* VIZ TAB */}
              {contentTab === "viz" && <Analytics jobs={jobs} />}
            </div>
          </div>
        </div>
      )}

      {/* ALGO LAB VIEW */}
      {view === "algo" && (
        <div style={{ flex: 1, overflow: "auto" }}>
          <AlgoLab userSkills={userProfile.skills} expLevel={userProfile.expLevel} />
        </div>
      )}

      {/* SAVED VIEW */}
      {view === "saved" && (
        <div style={{ flex: 1, overflow: "auto", padding: 24 }}>
          <div style={{ fontFamily: "'Syne',sans-serif", fontSize: 20, fontWeight: 700, marginBottom: 16 }}>
            Saved Jobs ({savedJobs.size})
          </div>
          {savedList.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">🔖</div>
              <div className="empty-title">No saved jobs yet</div>
              <div className="empty-sub">Save jobs from your recommendations to review them here.</div>
            </div>
          ) : (
            <div className="jobs-grid">
              {savedList.map((job, i) => (
                <JobCard
                  key={job.id}
                  job={job}
                  rank={i + 1}
                  userSkills={userProfile.skills}
                  savedJobs={savedJobs}
                  onSelect={handleSelectJob}
                  onSave={handleSave}
                  onApply={handleApply}
                  selected={false}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Toast */}
      <div className={`toast ${toast.show ? "show" : ""}`}>{toast.msg}</div>
    </div>
  );
}
