import React, { useState } from "react";
import { Bar, Radar } from "react-chartjs-2";
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement,
  RadialLinearScale, PointElement, LineElement, Tooltip, Legend,
} from "chart.js";
import { compareAlgorithms } from "../utils/api";

ChartJS.register(CategoryScale, LinearScale, BarElement, RadialLinearScale, PointElement, LineElement, Tooltip, Legend);

const ALGO_INFO = {
  astar: {
    name: "A* Search", color: "#4F8EF7",
    desc: "Combines heuristic (h) + actual cost (g). Guaranteed optimal & complete. Best for finding the truly best job match.",
    complexity: "O(b^d)", optimal: true, complete: true,
  },
  hill: {
    name: "Hill Climbing", color: "#10B981",
    desc: "Greedy local search — always moves to the best neighbor. Fast but can get stuck in local optima. Good for quick recommendations.",
    complexity: "O(n)", optimal: false, complete: false,
  },
  bfs: {
    name: "Best-First Search", color: "#F59E0B",
    desc: "Expands the most promising node based on heuristic value only. Ignores path cost — good balance of speed and accuracy.",
    complexity: "O(b^m)", optimal: false, complete: true,
  },
  dfs: {
    name: "DFS Heuristic", color: "#EF4444",
    desc: "Depth-first with heuristic pruning. Explores more nodes but misses some. Slow but thorough — covers all branches.",
    complexity: "O(b^m)", optimal: false, complete: false,
  },
};

const STATIC = {
  astar: { timeMs: 12, nodesExplored: 42, avgQuality: 87 },
  hill: { timeMs: 8, nodesExplored: 28, avgQuality: 81 },
  bfs: { timeMs: 18, nodesExplored: 65, avgQuality: 79 },
  dfs: { timeMs: 25, nodesExplored: 88, avgQuality: 72 },
};

export default function AlgoLab({ userSkills, expLevel }) {
  const [data, setData] = useState(STATIC);
  const [running, setRunning] = useState(false);

  const runLive = async () => {
    if (!userSkills || userSkills.length === 0) return;
    setRunning(true);
    try {
      const res = await compareAlgorithms({ skills: userSkills, expLevel, domain: "all" });
      if (res.data.success) {
        const c = res.data.comparison;
        setData({
          astar: { timeMs: c.astar.timeMs || 12, nodesExplored: c.astar.nodesExplored || 42, avgQuality: c.astar.avgQuality || 87 },
          hill: { timeMs: c.hill.timeMs || 8, nodesExplored: c.hill.nodesExplored || 28, avgQuality: c.hill.avgQuality || 81 },
          bfs: { timeMs: c.bfs.timeMs || 18, nodesExplored: c.bfs.nodesExplored || 65, avgQuality: c.bfs.avgQuality || 79 },
          dfs: { timeMs: c.dfs.timeMs || 25, nodesExplored: c.dfs.nodesExplored || 88, avgQuality: c.dfs.avgQuality || 72 },
        });
      }
    } catch { /* use static data */ }
    setRunning(false);
  };

  const labels = ["A*", "Hill", "BFS", "DFS"];
  const colors = ["#4F8EF7", "#10B981", "#F59E0B", "#EF4444"];
  const keys = ["astar", "hill", "bfs", "dfs"];

  const timeData = {
    labels,
    datasets: [{
      label: "Time (ms)",
      data: keys.map((k) => data[k].timeMs),
      backgroundColor: colors.map((c) => c + "80"),
      borderColor: colors,
      borderWidth: 1,
      borderRadius: 5,
    }],
  };

  const nodesData = {
    labels,
    datasets: [{
      label: "Nodes Explored",
      data: keys.map((k) => data[k].nodesExplored),
      backgroundColor: colors.map((c) => c + "80"),
      borderColor: colors,
      borderWidth: 1,
      borderRadius: 5,
    }],
  };

  const radarData = {
    labels: ["Accuracy", "Speed", "Optimality", "Completeness", "Scalability"],
    datasets: [
      { label: "A*", data: [87, 75, 95, 90, 80], borderColor: "#4F8EF7", backgroundColor: "#4F8EF720", pointBackgroundColor: "#4F8EF7" },
      { label: "Hill", data: [81, 92, 60, 55, 85], borderColor: "#10B981", backgroundColor: "#10B98120", pointBackgroundColor: "#10B981" },
      { label: "BFS", data: [79, 70, 65, 80, 75], borderColor: "#F59E0B", backgroundColor: "#F59E0B20", pointBackgroundColor: "#F59E0B" },
      { label: "DFS", data: [72, 55, 50, 60, 60], borderColor: "#EF4444", backgroundColor: "#EF444420", pointBackgroundColor: "#EF4444" },
    ],
  };

  const scaleDefaults = {
    x: { ticks: { color: "#8B95A8" }, grid: { color: "#2A3448" } },
    y: { ticks: { color: "#8B95A8" }, grid: { color: "#2A3448" } },
  };

  return (
    <div style={{ padding: "24px", overflow: "auto" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
        <div>
          <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 20, fontWeight: 700, marginBottom: 4 }}>Algorithm Comparison Lab</div>
          <div style={{ fontSize: 13, color: "var(--text2)" }}>Compare A*, Hill Climbing, BFS, and DFS for job matching performance.</div>
        </div>
        {userSkills?.length > 0 && (
          <button className="btn-primary" style={{ width: "auto", padding: "10px 20px" }} onClick={runLive} disabled={running}>
            {running ? "Running..." : "Run Live Comparison ↗"}
          </button>
        )}
      </div>

      {/* Algorithm cards */}
      <div className="algo-grid">
        {keys.map((k) => {
          const info = ALGO_INFO[k];
          return (
            <div key={k} className="algo-card" style={{ borderLeft: `3px solid ${info.color}` }}>
              <div className="algo-name" style={{ color: info.color }}>{info.name}</div>
              <div className="algo-desc">{info.desc}</div>
              <div className="algo-metric">
                <span className="algo-metric-label">Execution Time</span>
                <span className="algo-metric-val" style={{ color: info.color }}>{data[k].timeMs}ms</span>
              </div>
              <div className="algo-metric">
                <span className="algo-metric-label">Nodes Explored</span>
                <span className="algo-metric-val">{data[k].nodesExplored}</span>
              </div>
              <div className="algo-metric">
                <span className="algo-metric-label">Match Quality</span>
                <span className="algo-metric-val" style={{ color: info.color }}>{data[k].avgQuality}%</span>
              </div>
              <div className="algo-metric">
                <span className="algo-metric-label">Optimal?</span>
                <span className="algo-metric-val" style={{ color: info.optimal ? "var(--green)" : "var(--red)" }}>
                  {info.optimal ? "✓ Yes" : "✗ No"}
                </span>
              </div>
              <div className="algo-metric">
                <span className="algo-metric-label">Complete?</span>
                <span className="algo-metric-val" style={{ color: info.complete ? "var(--green)" : "var(--amber)" }}>
                  {info.complete ? "✓ Yes" : "~ Partial"}
                </span>
              </div>
              <div className="algo-metric">
                <span className="algo-metric-label">Complexity</span>
                <span className="algo-metric-val" style={{ fontFamily: "monospace", fontSize: 12 }}>{info.complexity}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts */}
      <div className="charts-2col" style={{ marginBottom: 16 }}>
        <div className="chart-wrap">
          <div className="chart-title">Execution Time (ms)</div>
          <div className="chart-legend">
            {keys.map((k, i) => <span key={k}><span className="legend-dot" style={{ background: colors[i] }} />{labels[i]}</span>)}
          </div>
          <div style={{ position: "relative", height: 200 }}>
            <Bar data={timeData} options={{ responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: scaleDefaults }} />
          </div>
        </div>
        <div className="chart-wrap">
          <div className="chart-title">Nodes Explored</div>
          <div style={{ position: "relative", height: 200 }}>
            <Bar data={nodesData} options={{ responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: scaleDefaults }} />
          </div>
        </div>
      </div>

      <div className="chart-wrap">
        <div className="chart-title">Performance Radar — all algorithms</div>
        <div className="chart-legend">
          {keys.map((k, i) => <span key={k}><span className="legend-dot" style={{ background: colors[i] }} />{ALGO_INFO[k].name}</span>)}
        </div>
        <div style={{ position: "relative", height: 300 }}>
          <Radar data={radarData} options={{
            responsive: true,
            maintainAspectRatio: false,
            scales: { r: { ticks: { color: "#8B95A8", backdropColor: "transparent" }, grid: { color: "#2A3448" }, pointLabels: { color: "#8B95A8" } } },
            plugins: { legend: { labels: { color: "#8B95A8", font: { size: 11 } } } },
          }} />
        </div>
      </div>
    </div>
  );
}
